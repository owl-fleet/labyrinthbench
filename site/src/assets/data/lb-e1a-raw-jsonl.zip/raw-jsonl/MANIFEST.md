# Raw-JSONL bundle MANIFEST — E1a Table-1 campaign (paired {control, wiped} depth sweep, nav-3)

Source: the lab's run output for the E1a campaign, copied as run. Per-line schema: one JSON object per run attempt
(`session_id`, `deg_id`, `found_exit`, `ramp_depth`, `lives_used`, `elapsed_seconds`,
`events`/`turns_log`, etc.), or `{"error": "..."}` for a failed attempt (no partial depth
data — matches the published brief tables exactly).

Two arms, two folders:

- `control/` — the **full 15-model cohort**, control arm only. Backs
  `lb-e1a-table1-control.md` (Table 1, full cohort, unaided baseline).
- `wiped/` — the **9 sub-ceiling models** run under `--overlay-only --show-recall`
  (registered scope, prereg Addendum A2). Backs `lb-e1a-table1-paired.md` (the promoted
  E1a paired curation datum, falsifier 7/9 at Δ≥5).

Every valid row's `n` here matches the brief tables exactly (`n_valid`/`n_error` in
`labyrinth-bench/results/e1a-table1/e1a_table1.json`) — this bundle is the un-aggregated
source those numbers were computed from.

## control/ (15 files, full cohort, n=6 valid + any errored attempts)

| File | Model | Arm | Run date | Lines (valid+err) | Bytes |
|---|---|---|---|---|---|
| e1a-deepseek-r1-70b-control.jsonl | deepseek-r1:70b | control | 2026-07-09 | 6 | 113,370 |
| e1a-gemma4-12b-control.jsonl | gemma4:12b | control | 2026-07-08 | 6 | 686,979 |
| e1a-gemma4-31b-control.jsonl | gemma4:31b | control | 2026-07-09 | 6 | 278,683 |
| e1a-glm-4-7-flash-control.jsonl | glm-4.7-flash | control | 2026-07-09 | 6 | 359,789 |
| e1a-gpt-oss-120b-control.jsonl | gpt-oss:120b | control | 2026-07-09 | 6 | 377,956 |
| e1a-hf-co-InternScience-Agents-A1-Q4_K_M-GGUF-control.jsonl | hf.co/InternScience/Agents-A1 (Q4_K_M) | control | 2026-07-09 | 9 (6 valid + 3 err) | 2,764,828 |
| e1a-hf-co-empero-ai-Qwythos-9B-Claude-Mythos-5-1M-GGUF-Q4_K_M-control.jsonl | Qwythos-9B (Q4_K_M) | control | 2026-07-07 | 7 (6 valid + 1 err) | 277,094 |
| e1a-llama3-3-70b-control.jsonl | llama3.3:70b | control | 2026-07-09 | 6 | 170,187 |
| e1a-llama4-scout-control.jsonl | llama4:scout | control | 2026-07-09 | 6 | 103,142 |
| e1a-ornith-9b-control.jsonl | ornith:9b | control | 2026-07-07 | 6 | 1,438,773 |
| e1a-qwen3-14b-control.jsonl | qwen3:14b | control | 2026-07-08 | 6 | 263,662 |
| e1a-qwen3-5-122b-control.jsonl | qwen3.5:122b | control | 2026-07-08 | 6 | 627,580 |
| e1a-qwen3-5-27b-control.jsonl | qwen3.5:27b | control | 2026-07-08 | 7 (6 valid + 1 err) | 705,423 |
| e1a-qwen3-5-9b-control.jsonl | qwen3.5:9b | control | 2026-07-08 | 6 | 1,788,040 |
| e1a-qwen3-6-27b-control.jsonl | qwen3.6:27b | control | 2026-07-08 | 6 | 407,929 |

## wiped/ (13 files: 9 sub-ceiling per Addendum A2 + 4 ceiling per Addendum A3, n=6 valid)

| File | Model | Arm | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| e1a-deepseek-r1-70b-wiped.jsonl | deepseek-r1:70b | wiped | 2026-07-11 | 6 | 286,996 |
| e1a-gemma4-12b-wiped.jsonl | gemma4:12b | wiped | 2026-07-11 | 6 | 1,010,303 |
| e1a-glm-4-7-flash-wiped.jsonl | glm-4.7-flash | wiped | 2026-07-11 | 6 | 611,743 |
| e1a-hf-co-empero-ai-Qwythos-9B-Claude-Mythos-5-1M-GGUF-Q4_K_M-wiped.jsonl | Qwythos-9B (Q4_K_M) | wiped | 2026-07-10 | 6 | 227,049 |
| e1a-llama3-3-70b-wiped.jsonl | llama3.3:70b | wiped | 2026-07-11 | 6 | 62,345 |
| e1a-llama4-scout-wiped.jsonl | llama4:scout | wiped | 2026-07-11 | 6 | 389,366 |
| e1a-ornith-9b-wiped.jsonl | ornith:9b | wiped | 2026-07-10 | 6 | 2,899,608 |
| e1a-qwen3-14b-wiped.jsonl | qwen3:14b | wiped | 2026-07-12 | 6 | 402,466 |
| e1a-qwen3-5-9b-wiped.jsonl | qwen3.5:9b | wiped | 2026-07-12 | 6 | 23,813,229 |

### Ceiling rows — Addendum A3 (added 2026-08-04, with the A3 brief)

The four ceiling-row efficiency arms (prereg Addendum A3, registered + signed off 2026-07-14;
campaign complete 2026-07-15, 0 errors). Backs `a3-ceiling-arm.md` and the A3 wiped cells in
the regenerated Tables 1/1b/1c. gpt-oss:120b's first line is the pre-campaign smoke run W0
(2026-07-14, depth 16 — counted, resume-aware, per the registered adjudication).

| File | Model | Arm | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| e1a-gemma4-31b-wiped.jsonl | gemma4:31b | wiped | 2026-07-15 | 6 | 124,596 |
| e1a-gpt-oss-120b-wiped.jsonl | gpt-oss:120b | wiped | 2026-07-14/15 | 6 | 237,525 |
| e1a-qwen3-5-122b-wiped.jsonl | qwen3.5:122b | wiped | 2026-07-15 | 6 | 515,080 |
| e1a-qwen3-6-27b-wiped.jsonl | qwen3.6:27b | wiped | 2026-07-15 | 6 | 306,757 |

Total: 28 files, control/ ≈ 10 MB, wiped/ ≈ 30 MB (qwen3.5:9b-wiped alone is 23.8 MB — it is
the one genuinely observe-heavy row, per the onboarding analysis; that verbosity is itself
part of the mechanism story, not an artifact).

## Scrub findings

Every file was grepped for private-network addresses, the operator's identity, host mount paths, internal
service names, credential shapes and email shapes before packing.

**One hit, one file:**

- `e1a-hf-co-InternScience-Agents-A1-Q4_K_M-GGUF-control.jsonl` — 3 of its 9 lines are
  errored attempts (Ollama HTTP 400s, already known/expected — this GGUF import is the
  "flaky GGUF" row named in the paired brief's Methods section). Each errored line's
  `"error"` field embeds the literal request URL of the model host.

  **Redaction applied:** that host address → `[lan-host]` (3 occurrences, field `error` only,
  same 3 lines). This is the *identical* mechanical transform `cli/e1a_table1.py`
  already applies to this exact error string when generating the public footnote in
  `e1a_table1.md`/`e1a_table1.json` (`re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b", "[lan-host]", cause)`)
  — the raw bundle now matches the aggregate table's existing disclosure precedent rather than
  introducing a new redaction convention. No other field, file, or line was touched.

**All other 23 files: zero hits, zero redactions.** Re-scrubbed the *staged* (post-copy)
directory with the same 13 patterns after copying — confirmed clean, including the redacted
file.

**A3 addition (2026-08-04):** the four ceiling-row wiped files above were added when the A3
brief landed, per this manifest's own earlier recommendation (a bundle should not carry data
no published brief contextualizes). All four were swept with the same 13 patterns before
inclusion: **zero hits, zero redactions** (the A3 campaign had no errored attempts, which is
where the one earlier redaction lived).

**Not included:** `_wiped_invalid_20260708/` (the first, bugged wiped campaign, archived
separately as invalid — the paired brief's Methods section already documents this explicitly
and says "no cell from it appears here").
