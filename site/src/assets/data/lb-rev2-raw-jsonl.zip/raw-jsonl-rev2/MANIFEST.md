# Raw-JSONL bundle MANIFEST — rev-2 look-gate campaign (observe-policy pilot + references)

Source of truth: the lab sandbox worktree's `results/` run-output directory — the same
canonical raw-data location the first bundle's manifest (`raw-jsonl/MANIFEST.md` inside
`lb-e1a-raw-jsonl.zip`) documents by full path. Per-line schema: one JSON object per run attempt (`session_id`, `deg_id`,
`found_exit`, `ramp_depth`, `lives_used`, `elapsed_seconds`, `events`/`turns_log`, plus the
look-gate instrumentation fields `look_gate`, `look_gate_interceptions`,
`look_gate_observe_cap`, `recommend_observe`, `run_label` where applicable). Substrate for
every run: rev-2 (deg manifest public in `degs/`, seed 2027, step budget 120, wrong-answer
budget 5).

This bundle backs `docs/annex/look-gate-result.md` — every arm reported in that brief's
tables maps to a file below. The mapping was frozen against the brief's published depth
vectors (each file's per-run `ramp_depth` multiset reproduces the corresponding table row),
not against filenames.

## pilot/ — the registered three-policy pilot (§3 pilot table)

One file, 18 runs, qwen3:14b, fresh and interleaved, n = 6 per policy. Each line
self-identifies its arm: `run_label` ∈ {`pilot-none`, `pilot-rec`, `pilot-forced`}, with the
mechanism flags `look_gate` (forced) and `recommend_observe` (recommended) set accordingly.

| File | Model | Arms | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| pilot-observe-policy-14b.jsonl | qwen3:14b | none / recommended / forced (6 each) | 2026-07-06 | 18 | 1,930,798 |

Depth check against the brief: none = {3,4,4,5,6,6} (median 4.5), recommended =
{4,5,5,6,7,7} (median 5.5), forced = {22,25,28,28,29,32} (median 28.0) — exact match,
including the depth-32 record run analyzed in the brief's §4 trace-mechanism pass.

## control/ — the older control of record (raw qwen3:14b, median 5.5)

Two files jointly hold the n = 6 valid control runs the brief cites as the control of
record (depths {4,4,5,6,6,8}, median 5.5).

| File | Model | Arm | Run date | Lines (valid+err) | Bytes |
|---|---|---|---|---|---|
| rev2-control-14b.jsonl | qwen3:14b | control | 2026-06-03 | 3 | 176,750 |
| rev2-control-14b-topup.jsonl | qwen3:14b | control | 2026-07-05 | 4 (3 valid + 1 errored) | 196,446 |
| rev2-control-14b.log | — | harness log for the 2026-06-03 runs | 2026-06-03 | 15 | 675 |

The topup file's errored line is a null-fields placeholder for a failed attempt (no partial
depth data), matching the first bundle's errored-attempt convention.

## look-gate/ — the registered enforcement arm (median 21, capped)

| File | Model | Arm | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| rev2-look-gate-14b-capped.jsonl | qwen3:14b | `--look-gate` + observe-cap (registered) | 2026-07-06 | 6 | 1,136,408 |

Depths {18,20,21,21,25,29}, median 21 — the brief's registered enforcement cell.

## references/ — tuned-model and agent-frame reference points

| File | Model | Arm | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| rev2-devstral-24b.jsonl | devstral:24b | unaided (agent-tuned, dense) | 2026-07-06 | 6 | 215,450 |
| rev2-qwen3coder-30b.jsonl | qwen3-coder:30b | unaided (agent-tuned, MoE) | 2026-07-05 | 6 | 180,001 |
| rev2-wali-14b.jsonl | qwen3:14b | ReAct-orchestrated (local agent frame external to the harness) | 2026-07-05 | 9 | 607,942 |

Depth checks: Devstral {12,15,22,25,29,29} median 23.5; qwen3-coder {10,21,28,29,33,33}
median 28.5 — both exact matches to the brief.

The ReAct-orchestrated file preserves **all nine attempts** of that arm: eight
out-of-lives runs (depths {6,6,7,7,7,7,10,10}, median 7 — the brief's reported median) plus
one protocol failure (`failure_reason: "wali_loop_exhausted"`, depth 2). The brief reports
this reference at n = 6; the raw file is the complete attempt record and ships un-curated.
Its per-line fields name the orchestrating agent frame ("Wali", this lab's local ReAct
agent) in counter fields (`wali_parse_failures`, `wali_chat_lapses`); these ship as-is —
they are run counters, not infrastructure identifiers.

## reference-120b/ — the unaided gpt-oss:120b reference (current + superseded)

| File | Model | Arm | Run date | Lines | Bytes |
|---|---|---|---|---|---|
| rev2-control-120b-rerun.jsonl | gpt-oss:120b | unaided, journal-verified context (n_ctx_slot 32768) | 2026-07-16 | 9 | 786,080 |
| rev2-120b-rerun.log | — | rerun harness/journal log (records `n_ctx_slot=32768 (journal-verified)`) | 2026-07-16 | 41 | 2,549 |
| rev2-control-120b.jsonl | gpt-oss:120b | unaided, superseded 2026-06-03 reference (context unverified) | 2026-06-03 | 3 | 267,922 |
| rev2-control-120b.log | — | harness log | 2026-06-03 | 26 | 1,513 |
| rev2-control-120b-extra.jsonl | gpt-oss:120b | unaided, superseded reference (continuation) | 2026-06-03 | 6 | 510,773 |
| rev2-control-120b-extra.log | — | harness log | 2026-06-03 | 36 | 2,002 |

The rerun's nine depths are all 34 (zero variance) — the reference of record since the
2026-07-16 revision. The two 2026-06-03 files jointly hold the superseded reference the
brief keeps as the record of the superseded number: depths {21,29,29,33,34,34,34,34,34},
median 34, population sd 4.16 (the brief's "sd 4.2").

## Scope

Arms in the brief's tables and nothing else. The sandbox results directory also holds
exploratory rev-2 cells (accum/managed/placebo/pull-* variants, other models) from the
corridor's development history; those are not cited by the published brief and are not in
this bundle, matching the first bundle's scope convention (bundle = what the briefs report).

Total: 14 files, ~6.0 MB uncompressed.

## Scrub findings (this session)

Grepped all candidate files (pre- and post-staging) with the full `pre-push-scan.sh`
battery plus the first bundle's 13-pattern list — operator identity, email shapes, LAN
IPv4 shapes, host mount paths, PEM private-key blocks, DSN shapes, API-key shapes,
internal lab service names, and private lab-notebook paths. (Pattern literals are not
reproduced here so this manifest does not itself trip the scan; the exact battery is
public at `scripts/pre-push-scan.sh` in the repo.)

**One hit class, one file:**

- `rev2-control-120b-rerun.jsonl` — all 9 lines carry the run's model-endpoint URL in a
  `base_url` field: `http://<private-LAN-IPv4>:11434/v1` (host `.12` = the workstation the
  120B reference ran on — the same host, same field class as the first bundle's single
  finding).

  **Redaction applied:** the LAN address → `[lan-host]` (9 occurrences, `base_url` field
  only). This is the identical mechanical transform the first bundle applied and that
  `cli/e1a_table1.py` applies when generating public aggregate tables — same redaction
  convention, no new one introduced. No other field, file, or line was touched.

**All other files: zero hits, zero redactions.** The staged (post-copy, post-redaction)
tree was re-scanned with the same battery and is clean; every JSONL line in the staged tree
parses as valid JSON after redaction.
