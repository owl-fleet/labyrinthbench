# Raw-JSONL bundle MANIFEST: the MCV brief (what in an agent's context is load-bearing), nav-3

One JSON object per run attempt, one file per table cell of `docs/annex/marginal-context-value.md`, grouped by section.
A `{"error": ...}` row is an attempt that never produced a run (the 3.2 GPU fault); it carries no depth.
Model-host addresses are redacted to `[lan-host]`. Every other byte is as-run.

Replay: `python3 cli/verify.py <file>` from the repo root. Control and no-refresh rows replay byte-for-byte.
Rows from refresh arms (R) do not yet: the harness's free `observe` adds an engine event per turn that the re-drive
does not reproduce (tracked as issue #26). The `verify.py` column below is what the verifier reports today.

| Section | File | Table arm | Policy and flags | Model | Run date | Rows (valid + err) | Bytes | verify.py |
|---|---|---|---|---|---|---|---|---|
| 3.1-addition | `3.1-addition/rung2b-accumulate.jsonl` | accumulate | `accumulate` | qwen3:14b | 2026-09-04 | 6 + 0 | 270,389 | 6/6 |
| 3.1-addition | `3.1-addition/rung2b-accumulate-ledger.jsonl` | accumulate + answer record | `accumulate+ledger` | qwen3:14b | 2026-09-04 | 6 + 0 | 218,382 | 6/6 |
| 3.1-addition | `3.1-addition/rung2b-drop-old-engine.jsonl` | accumulate, old engine text dropped | `drop-old-engine` | qwen3:14b | 2026-09-04 | 6 + 0 | 363,644 | 6/6 |
| 3.1-addition | `3.1-addition/rung2b-wipe-curated.jsonl` | W+R+M | `wipe-curated --show-recall` | qwen3:14b | 2026-09-04 | 6 + 0 | 351,254 | 0/6 |
| 3.2-2x2 | `3.2-2x2/rung2c-accumulate.jsonl` | accumulate | `accumulate` | qwen3:14b | 2026-09-09 | 11 + 1 | 471,321 | 11/11 |
| 3.2-2x2 | `3.2-2x2/rung2c-accumulate-refresh.jsonl` | accumulate + R | `accumulate+refresh` | qwen3:14b | 2026-09-09 | 12 + 0 | 533,493 | 0/12 |
| 3.2-2x2 | `3.2-2x2/rung2c-wipe-curated-norefresh.jsonl` | W+M (no refresh) | `wipe-curated-norefresh --show-recall` | qwen3:14b | 2026-09-09 | 11 + 1 | 845,312 | 11/11 |
| 3.2-2x2 | `3.2-2x2/rung2c-wipe-curated.jsonl` | W+R+M | `wipe-curated --show-recall` | qwen3:14b | 2026-09-09 | 12 + 0 | 760,885 | 0/12 |
| 3.3-rung-iii | `3.3-rung-iii/rung3-A.jsonl` | accumulate | `accumulate` | qwen3:14b | 2026-09-26 | 6 + 0 | 291,508 | 6/6 |
| 3.3-rung-iii | `3.3-rung-iii/rung3-C.jsonl` | W+R+M | `wipe-curated --show-recall` | qwen3:14b | 2026-09-26 | 6 + 0 | 356,968 | 0/6 |
| 3.3-rung-iii | `3.3-rung-iii/rung3-D.jsonl` | W+M | `wipe-curated-norefresh --show-recall` | qwen3:14b | 2026-09-26 | 6 + 0 | 370,235 | 6/6 |
| 3.3-rung-iii | `3.3-rung-iii/rung3-E.jsonl` | W+R (no recall) | `wipe-curated (no --show-recall)` | qwen3:14b | 2026-09-26 | 6 + 0 | 530,159 | 0/6 |
| 3.3-rung-iii | `3.3-rung-iii/rung3-F.jsonl` | W+M+L | `wipe-curated-norefresh --show-recall --force-observe-after-wrong` | qwen3:14b | 2026-09-26 | 6 + 0 | 645,905 | 6/6 |
| 3.4-llama70b | `3.4-llama70b/pad70b-A.jsonl` | accumulate | `accumulate` | llama3.3:70b | 2026-09-28 | 6 + 0 | 280,300 | 6/6 |
| 3.4-llama70b | `3.4-llama70b/pad70b-C.jsonl` | W+R+M | `wipe-curated --show-recall` | llama3.3:70b | 2026-09-28 | 6 + 0 | 106,212 | 0/6 |
| 3.4-llama70b | `3.4-llama70b/pad70b-K.jsonl` | W+R+M+K | `wipe-curated+actions --show-recall` | llama3.3:70b | 2026-09-28 | 6 + 0 | 182,980 | 0/6 |
| 3.4-llama70b | `3.4-llama70b/pad70b-P.jsonl` | W+R+M+P | `wipe-curated+pad --show-recall` | llama3.3:70b | 2026-09-28 | 6 + 0 | 107,091 | 0/6 |

Depths per file, in file order, so a reader can match the tables without parsing:

- `3.1-addition/rung2b-accumulate.jsonl`: 2 2 8 6 3 2
- `3.1-addition/rung2b-accumulate-ledger.jsonl`: 3 3 3 5 2 3
- `3.1-addition/rung2b-drop-old-engine.jsonl`: 4 4 5 4 4 4
- `3.1-addition/rung2b-wipe-curated.jsonl`: 7 20 20 8 20 20
- `3.2-2x2/rung2c-accumulate.jsonl`: 3 3 3 2 3 4 3 3 9 2 3
- `3.2-2x2/rung2c-accumulate-refresh.jsonl`: 4 4 5 4 4 5 8 4 4 5 4 4
- `3.2-2x2/rung2c-wipe-curated-norefresh.jsonl`: 16 7 7 8 12 7 3 7 7 7 7
- `3.2-2x2/rung2c-wipe-curated.jsonl`: 7 20 20 20 20 20 20 20 20 20 20 8
- `3.3-rung-iii/rung3-A.jsonl`: 5 8 3 3 3 2
- `3.3-rung-iii/rung3-C.jsonl`: 20 20 20 20 20 20
- `3.3-rung-iii/rung3-D.jsonl`: 2 4 7 4 20 7
- `3.3-rung-iii/rung3-E.jsonl`: 1 2 2 2 1 1
- `3.3-rung-iii/rung3-F.jsonl`: 9 20 20 12 7 8
- `3.4-llama70b/pad70b-A.jsonl`: 15 15 15 16 16 15
- `3.4-llama70b/pad70b-C.jsonl`: 9 9 9 9 9 9
- `3.4-llama70b/pad70b-K.jsonl`: 19 9 18 17 19 9
- `3.4-llama70b/pad70b-P.jsonl`: 9 9 9 9 9 9
